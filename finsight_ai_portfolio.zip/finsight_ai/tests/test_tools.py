from src.generate_data import *
from src.tools import variance_analysis, anomaly_detection, revenue_forecast

def test_variance_analysis():
    df=variance_analysis(5)
    assert len(df)==5
    assert {'budget','actual','variance','variance_pct'}.issubset(df.columns)

def test_anomaly_detection():
    df=anomaly_detection()
    assert 'anomaly' in df.columns

def test_forecast():
    df=revenue_forecast(3)
    assert len(df)==12
    assert (df.forecast_revenue > 0).all()
