# FinSight AI — Agentic FP&A & ERP Analytics Copilot

A portfolio project combining FP&A, ERP/MIS analytics, SQL, Python, data visualization, ML anomaly detection, and agentic AI.

## What it does
- Loads synthetic ERP-style P&L transactions and monthly budgets into SQLite.
- Lets a user ask business questions in natural language.
- Routes questions to specialized tools: SQL KPI analysis, variance analysis, anomaly detection, forecast, and visualization.
- Generates an executive-ready management summary using Gemini API (free tier) or Ollama (local), with a deterministic fallback when no LLM is configured.
- Converts material findings into PM-style actions with priority, owner role, impact and due date.

## Portfolio story
**Business problem:** Finance leaders receive fragmented ERP/MIS data and spend time manually reconciling variances, identifying cost drivers, and preparing management commentary.

**Solution:** An AI copilot that connects structured financial data with analytical tools and turns questions into evidence-backed insights and action items.

## Skills demonstrated
Python • SQL • pandas • SQLite • Plotly • scikit-learn • Streamlit • LLM/API integration • Agentic tool routing • FP&A • variance analysis • forecasting • anomaly detection • product management

## Run locally
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python -m src.generate_data
streamlit run app.py
```

Optional LLM setup:
```bash
copy .env.example .env
# Add GEMINI_API_KEY, or install Ollama and set LLM_PROVIDER=ollama
```

## Example questions
- Which business unit has the largest unfavorable cost variance?
- Show me the top 5 cost drivers for August.
- Which months have unusual spending patterns?
- Forecast next quarter revenue by business unit.
- Create management actions for the highest-risk variances.

## Repository map
- `app.py` — Streamlit dashboard
- `src/agent.py` — tool-routing agent
- `src/tools.py` — SQL, variance, anomaly, forecast and chart tools
- `src/llm.py` — Gemini / Ollama / fallback model adapter
- `src/pm_actions.py` — PM-style action generation
- `data/` — synthetic ERP dataset and SQLite database
- `notebooks/` — Kaggle-friendly walkthrough notebook
- `docs/PRD.md` — product requirements document
- `docs/ARCHITECTURE.md` — system design and data flow

## Data privacy
All project data is synthetic. No employer, client or confidential financial data is used.
