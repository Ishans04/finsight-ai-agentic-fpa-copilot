from pathlib import Path
import sqlite3
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'
DATA.mkdir(exist_ok=True)

rng = np.random.default_rng(42)
months = pd.date_range('2025-01-01', '2026-08-01', freq='MS')
business_units = ['North America', 'EMEA', 'APAC', 'India']
cost_categories = ['Payroll', 'Cloud', 'Travel', 'Software', 'Professional Services', 'Facilities', 'Marketing']
revenue_base = {'North America': 5.2, 'EMEA': 3.6, 'APAC': 2.8, 'India': 2.1}

rows = []
for month in months:
    for bu in business_units:
        season = 1 + 0.06 * np.sin(month.month / 12 * 2 * np.pi)
        revenue = revenue_base[bu] * 1_000_000 * (1 + 0.012 * (month - months[0]).days / 30) * season
        revenue *= rng.normal(1, 0.035)
        for cat in cost_categories:
            share = {'Payroll': .42, 'Cloud': .16, 'Travel': .06, 'Software': .12, 'Professional Services': .10, 'Facilities': .07, 'Marketing': .07}[cat]
            budget = revenue * share
            actual = budget * rng.normal(1.0, 0.08)
            # Inject a few realistic adverse events.
            if month.strftime('%Y-%m') == '2026-06' and bu == 'EMEA' and cat == 'Cloud': actual *= 1.30
            if month.strftime('%Y-%m') == '2026-07' and bu == 'APAC' and cat == 'Travel': actual *= 1.45
            if month.strftime('%Y-%m') == '2026-08' and bu == 'India' and cat == 'Professional Services': actual *= 1.35
            rows.append([month.date(), bu, cat, round(revenue, 2), round(budget, 2), round(actual, 2)])

transactions = pd.DataFrame(rows, columns=['month','business_unit','cost_category','revenue','budget','actual'])
transactions['variance'] = transactions['actual'] - transactions['budget']
transactions['variance_pct'] = transactions['variance'] / transactions['budget']
transactions.to_csv(DATA / 'erp_finance_data.csv', index=False)

budgets = transactions.groupby(['month','business_unit'], as_index=False).agg(revenue_budget=('revenue','sum'), opex_budget=('budget','sum'))
budgets.to_csv(DATA / 'monthly_budgets.csv', index=False)

con = sqlite3.connect(DATA / 'finsight.db')
transactions.to_sql('finance_transactions', con, if_exists='replace', index=False)
budgets.to_sql('monthly_budgets', con, if_exists='replace', index=False)
con.execute('CREATE INDEX IF NOT EXISTS idx_finance_month_bu ON finance_transactions(month,business_unit)')
con.commit(); con.close()
print(f'Created {len(transactions):,} rows in {DATA / "erp_finance_data.csv"}')
